## 数据集地址：

预处理数据集：resized_pp2021_fgvc8_train_data：https://www.kaggle.com/crissallan/resized-plantpathology2021fgvc8-train-data-new/download

原数据集：Plant Pathology 2021 - FGVC8：https://www.kaggle.com/c/plant-pathology-2021-fgvc8/data

